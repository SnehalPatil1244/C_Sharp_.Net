﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_Information_Details_App
{
    class Shared_Content
    {
        public static string UName = "UnKnown";
    }
}
